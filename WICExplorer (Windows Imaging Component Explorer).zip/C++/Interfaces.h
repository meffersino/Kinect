//----------------------------------------------------------------------------------------
// THIS CODE AND INFORMATION IS PROVIDED "AS-IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//----------------------------------------------------------------------------------------

MP(IWICBitmapScaler)
MP(IWICBitmapSource)
MP(IWICBitmapClipper)
MP(IWICBitmapEncoder)
MP(IWICBitmapFrameEncode)
MP(IWICBitmapDecoder)
MP(IWICBitmapFrameDecode)
MP(IWICBitmapCodecInfo)
MP(IWICBitmapEncoderInfo)
MP(IWICBitmapDecoderInfo)
MP(IWICPixelFormatInfo)
MP(IWICBitmapFlipRotator)
MP(IWICBitmapLock)
MP(IWICBitmap)
MP(IWICColorContext)
MP(IWICColorTransform)
MP(IWICComponentInfo)
MP(IWICFormatConverter)
MP(IWICMetadataWriter)
MP(IWICMetadataBlockReader)
MP(IWICMetadataHandlerInfo)
MP(IWICMetadataReader)
MP(IWICImagingFactory)
MP(IWICPalette)
MP(IWICStream)
MP(IWICComponentFactory)
MP(IWICMetadataQueryWriter)
MP(IWICMetadataQueryReader)
MP(IWICProgressiveLevelControl);
