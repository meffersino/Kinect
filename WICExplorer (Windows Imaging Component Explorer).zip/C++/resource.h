//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WICExplorer.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDB_MAINTREE                    202
#define IDD_ENCODER_SELECTION           203
#define IDD_DIALOG1                     204
#define IDD_QLPATH                      204
#define IDC_ENCODER_LIST                1003
#define IDC_CUSTOM1                     1004
#define IDC_FORMAT_LIST                 1004
#define IDC_EDIT1                       1005
#define IDC_ACTUAL_FORMAT               1005
#define IDC_QLPATH                      1005
#define ID_FILE_OPEN_DIR                32772
#define ID_SHOW_VIEWPANE                32773
#define ID_FILE_LOAD                    32774
#define ID_FILE_UNLOAD                  32775
#define ID_FIND_METADATA                32776
#define ID_SHOW_ALPHA                   32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
